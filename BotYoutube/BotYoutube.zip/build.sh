#!/bin/bash

zip -r "BotYoutube.zip" * -x "BotYoutube.zip"